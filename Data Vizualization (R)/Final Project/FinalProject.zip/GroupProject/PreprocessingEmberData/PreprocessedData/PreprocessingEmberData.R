# Libraries
library(dplyr)
library(readr)

# ---- COUNTRY INDICATORS ---- #

# Reading HOURLY data
country_hourly_2030 <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Country indicators/country_hourly_chart_2030.csv")
country_hourly_2040 <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Country indicators/country_hourly_chart_2040.csv")

# Rename the columns
country_hourly_2030 <- country_hourly_2030 %>%
  rename(`RES-E 2030` = `RES-E`, `NET-P 2030` = `NET-P`)

country_hourly_2040 <- country_hourly_2040 %>%
  rename(`RES-E 2040` = `RES-E`, `NET-P 2040` = `NET-P`)

# Merging
merge_country_hourly_df <- full_join(
  country_hourly_2030,
  country_hourly_2040,
  by = c("Country", "Hour", "RES-E 2024", "NET-P 2024")
)

# Filling the missing values with 0
merge_country_hourly_df[is.na(merge_country_hourly_df)] <- 0

#######################################

# Reading MONTHLY data
country_monthly_2030 <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Country indicators/country_monthly_chart_2030.csv")
country_monthly_2040 <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Country indicators/country_monthly_chart_2040.csv")

# Rename the columns
country_monthly_2030 <- country_monthly_2030 %>%
  rename(`RES-E 2030` = `RES-E`, `NET-P 2030` = `NET-P`)

country_monthly_2040 <- country_monthly_2040 %>%
  rename(`RES-E 2040` = `RES-E`, `NET-P 2040` = `NET-P`)

# Merging
merge_country_monthly_df <- full_join(
  country_monthly_2030,
  country_monthly_2040,
  by = c("Country", "Month", "RES-E 2024", "NET-P 2024")
)

# Filling the missing values with 0
merge_country_monthly_df[is.na(merge_country_monthly_df)] <- 0

# Saving the data sets into CSV files
write_csv(merge_country_hourly_df, "C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/PreprocessedData/merge_country_hourly_df.csv")
write_csv(merge_country_monthly_df, "C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/PreprocessedData/merge_country_monthly_df.csv")


# ---- FLOW INDICATORS ---- #

# Reading HOURLY data
flows_hourly_2024 <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Flow indicators/flows_hourly_chart_2024.csv")
flows_hourly_2030 <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Flow indicators/flows_hourly_chart_2030.csv")
flows_hourly_2040 <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Flow indicators/flows_hourly_chart_2040.csv")

# Rename the columns
flows_hourly_2024 <- flows_hourly_2024 %>%
  rename(`Flow 2024` = `Flow`)

flows_hourly_2030 <- flows_hourly_2030 %>%
  rename(`Flow 2030` = `Flow`)

flows_hourly_2040 <- flows_hourly_2040 %>%
  rename(`Flow 2040` = `Flow`)

# Merging
merge_flow_hourly_df <- full_join(
  flows_hourly_2024, 
  flows_hourly_2030,
  by = c("Country From", "Hour", "Country To")
)

merge_flow_hourly_df <- full_join(
  merge_flow_hourly_df, 
  flows_hourly_2040,
  by = c("Country From", "Hour", "Country To")
)

# Filling the missing values with 0
merge_flow_hourly_df[is.na(merge_flow_hourly_df)] <- 0

#######################################

# Reading MONTHLY data
flows_monthly_2024 <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Flow indicators/flows_monthly_chart_2024.csv")
flows_monthly_2030 <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Flow indicators/flows_monthly_chart_2030.csv")
flows_monthly_2040 <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Flow indicators/flows_monthly_chart_2040.csv")

# Rename the columns
flows_monthly_2024 <- flows_monthly_2024 %>%
  rename(`Flow 2024` = `Flow`)

flows_monthly_2030 <- flows_monthly_2030 %>%
  rename(`Flow 2030` = `Flow`)

flows_monthly_2040 <- flows_monthly_2040 %>%
  rename(`Flow 2040` = `Flow`)

# Merging
merge_flow_monthly_df <- full_join(
  flows_monthly_2024, 
  flows_monthly_2030,
  by = c("Country From", "Month", "Country To")
)

merge_flow_monthly_df <- full_join(
  merge_flow_monthly_df, 
  flows_monthly_2040,
  by = c("Country From", "Month", "Country To")
)

# Filling the missing values with 0
merge_flow_monthly_df[is.na(merge_flow_monthly_df)] <- 0

# Saving the data sets into CSV files
write_csv(merge_flow_hourly_df, "C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/PreprocessedData/merge_flow_hourly_df.csv")
write_csv(merge_flow_monthly_df, "C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/PreprocessedData/merge_flow_monthly_df.csv")


# ---- IMPORT POTENTIAL ---- #

# Reading the data
import_potential_2030 <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Import potential/imp_pot_chart_2030.csv")
import_potential_2040 <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Import potential/imp_pot_chart_2040.csv")

# Rename the columns
import_potential_2030 <- import_potential_2030 %>%
  rename(`Reference 2030` = `Reference`, `Projects 2030` = `Projects`, `Needs 2030` = `Needs`)

import_potential_2040 <- import_potential_2040 %>%
  rename(`Reference 2040` = `Reference`, `Projects 2040` = `Projects`, `Needs 2040` = `Needs`)

# Merging
merge_import_potential_df <- full_join(
  import_potential_2030,
  import_potential_2040,
  by = c("Country")
)


# Creating the columns "2024" by calculating the mean of the columns "2024.x" and "2024.y"
merge_import_potential_df$`2024` <- rowMeans(
  merge_import_potential_df[, c("2024.x", "2024.y")],
  na.rm = TRUE
)

# Dropping the rows "2024.x" and "2024.y"
merge_import_potential_df <- merge_import_potential_df %>%
  select(-c(`2024.x`, `2024.y`))

# Filling the missing values with 0
merge_import_potential_df[is.na(merge_import_potential_df)] <- 0

# Saving the data set into CSV files
write_csv(merge_import_potential_df, "C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/PreprocessedData/merge_import_potential_df.csv")


# ---- INTERCONNECTORS ---- #

# Reading the data
needs_ntc_df <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Interconnectors/NEEDS_NTC.csv")
proj_ntc_df <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Interconnectors/PROJ_NTC.csv")
ref_ntc_df <- read_csv("C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/europe_interconnection_data/Interconnectors/REF_NTC.csv")

# Rename the columns
needs_ntc_df <- needs_ntc_df %>%
  rename(`Needs_NTC_F` = `NTC_F`, `Needs_NTC_B` = `NTC_B`)

proj_ntc_df <- proj_ntc_df %>%
  rename(`Proj_NTC_F` = `NTC_F`, `Proj_NTC_B` = `NTC_B`)

ref_ntc_df <- ref_ntc_df %>%
  rename(`Ref_NTC_F` = `NTC_F`, `Ref_NTC_B` = `NTC_B`)

# Merging
merge_ntc_df <- full_join(
  needs_ntc_df,
  proj_ntc_df,
  by = c("Border", "From", "To", "Year")
)

merge_ntc_df <- full_join(
  merge_ntc_df,
  ref_ntc_df,
  by = c("Border", "From", "To", "Year")
)

# Filling the missing values with 0
merge_ntc_df[is.na(merge_ntc_df)] <- 0

# Saving the data set into CSV files
write_csv(merge_ntc_df, "C:/Users/Tamás/Desktop/ESMT/FirstSem/DataVisualization/GroupProject/PreprocessingEmberData/PreprocessedData/merge_ntc_df.csv")

