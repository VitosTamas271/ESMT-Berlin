DATA IN THE ARCHIVE

- peak_demand.csv: peak demand (MW) per country-year, as considered in the analysis behind the data tool.
- REF_NTC.csv: 2024 or Reference interconnector capacity (MW) per border-year. Includes both forward and backward NTC.
- PROJ_NTC.csv: Projects interconnector capacity (MW) per border-year. Includes both forward and backward NTC, for 2030 and 2040 only.
- NEEDS_NTC.csv: Needs interconnector capacity (MW) per border-year. Includes both forward and backward NTC, for 2030 and 2040 only.
- imp_pot_chart_YYYY.csv: Import Potential (%) for year YYYY, per country-category.
- country_hourly_chart_YYYY.csv: hour-of-day averages of Net Position and Variable RES Penetration indicators (%) for year YYYY, per country.
- country_monthly_chart_YYYY.csv: monthly averages of Net Position and Variable RES Penetration indicators (%) for year YYYY, per country.
- flows_hourly_chart_YYYY.csv: hour-of-day averages of the Cross-border Flows indicators (%) for year YYYY, per country-line.
- flows_monthly_chart_YYYY.csv: hour-of-day averages of the Cross-border Flows indicators (%) for year YYYY, per country-line.

For more information, consult Ember's Europe Electricity Interconnection Data Tool on https://ember-energy.org/